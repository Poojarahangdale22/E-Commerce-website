from django.shortcuts import render,redirect
from .models import Product, Orders, OrderUpdate, Contacts,userdata,mycart,PaymentMaster
from math import ceil
import json
from django.contrib import messages

# Create your views here.
from django.http import HttpResponse


def index(request):
    allProds = []
    catprods = Product.objects.values('category', 'id')
    cats = {item['category'] for item in catprods}
    for cat in cats:
        prod = Product.objects.filter(category=cat)
        n = len(prod)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        allProds.append([prod, range(1, nSlides), nSlides])
    params = {'allProds':allProds}
    return render(request, 'shop/index.html', params)


def about(request):
    return render(request, 'shop/about.html')


def contactus(request):

    return render(request,"shop/contact.html",{})

def contact_process(request):

    if request.method=="POST":
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        desc = request.POST['desc']
        contact = Contacts()
        contact.name = name
        contact.email =email
        contact.phone =phone
        contact.desc = desc
        contact.save()

        #after saving the contacting form

        allProds = []
        catprods = Product.objects.values('category', 'id')
        cats = {item['category'] for item in catprods}
        for cat in cats:
            prod = Product.objects.filter(category=cat)
            n = len(prod)
            nSlides = n // 4 + ceil((n / 4) - (n // 4))
            allProds.append([prod, range(1, nSlides), nSlides])
        params = {'allProds':allProds}
        return render(request, 'shop/index.html', params)


       


def tracker(request):
    if request.method=="POST":
        orderId = request.POST.get('orderId', '')
        email = request.POST.get('email', '')
        try:
            order = Orders.objects.filter(order_id=orderId, email=email)
            if len(order)>0:
                update = OrderUpdate.objects.filter(order_id=orderId)
                updates = []
                for item in update:
                    updates.append({'text': item.update_desc, 'time': item.timestamp})
                    response = json.dumps(updates, default=str)
                return HttpResponse(response)
            else:
                return HttpResponse('{}')
        except Exception as e:
            return HttpResponse('{}')

    return render(request, 'shop/tracker.html')


def search(request):
    return render(request, 'shop/search.html')


def productView(request, myid):

    # Fetch the product using the id
    product = Product.objects.filter(id=myid)
    return render(request, 'shop/prodView.html', {'product':product[0]})


def checkout(request):
    if request.method=="POST":
        items_json = request.POST.get('itemsJson', '')
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        address = request.POST.get('address1', '') + " " + request.POST.get('address2', '')
        city = request.POST.get('city', '')
        state = request.POST.get('state', '')
        zip_code = request.POST.get('zip_code', '')
        phone = request.POST.get('phone', '')
        order = Orders(items_json=items_json, name=name, email=email, address=address, city=city,
                       state=state, zip_code=zip_code, phone=phone)
        order.save()
        update = OrderUpdate(order_id=order.order_id, update_desc="The order has been placed")
        update.save()
        thank = True
        id = order.order_id
        return render(request, 'shop/checkout.html', {'thank':thank, 'id': id})
    return render(request, 'shop/checkout.html')

def signup(request):

    return render(request,"shop/signup.html",{})

def adduser(request):

    if request.method=="POST":
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        password = request.POST['password']
        user = userdata()
        user.name = name
        user.email =email
        user.phone =phone
        user.password = password
        user.save()
        request.session["name"]=name



        allProds = []
        catprods = Product.objects.values('category', 'id')
        cats = {item['category'] for item in catprods}
        for cat in cats:
            prod = Product.objects.filter(category=cat)
            n = len(prod)
            nSlides = n // 4 + ceil((n / 4) - (n // 4))
            allProds.append([prod, range(1, nSlides), nSlides])
        params = {'allProds':allProds}
        return render(request, 'shop/index.html', params)


def login(request):
    return render(request,"shop/login.html",{})


def userlogin(request):
    if request.method == 'POST':
        email = request.POST['email']
        passw = request.POST['password']
        request.session['email'] = email
        try:
            user = userdata.objects.get(email=email,password=passw)
        except:
            return redirect(index)
        else:
            print("user fetched.......................!")
            request.session['name'] = user.name
            name = request.session['name']
            print(name)
            allProds = []
            catprods = Product.objects.values('category', 'id')
            cats = {item['category'] for item in catprods}
            for cat in cats:
                prod = Product.objects.filter(category=cat)
                n = len(prod)
                nSlides = n // 4 + ceil((n / 4) - (n // 4))
                allProds.append([prod, range(1, nSlides), nSlides])
            params = {'allProds':allProds,'name':name}
            
            return render(request, 'shop/index.html', params)
    return render(request, 'shop/login.html',{})

def logout(request):
    request.session.clear()
    allProds = []
    catprods = Product.objects.values('category', 'id')
    cats = {item['category'] for item in catprods}
    for cat in cats:
        prod = Product.objects.filter(category=cat)
        n = len(prod)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        allProds.append([prod, range(1, nSlides), nSlides])
        
    params = {'allProds':allProds}
    
    return render(request, 'shop/index.html',params)
   
def showallcartitems(request):
    if "email" in request.session:
        total = 0
        user = request.session['email']
        buyer = userdata.objects.get(email=user)

        my_products= mycart.objects.filter(user=buyer)
        print(my_products)

        for item in my_products:
            
            total+= item.quantity*item.item.price
        request.session["total"] = total


    return render(request,"shop/showallcartitems.html",{"items":my_products})
def addtocart(request,id):
    
    
    if "email" in request.session:
        total = 0
        user = request.session['email']
        id = id
        buyer = userdata.objects.get(email=user)
        print(buyer)
        product = Product.objects.get(id=id)
        print(product,"---------------prodcut fethed")
        qty=1
        newitem = mycart()
        newitem.quantity = qty
        newitem.item = product
        newitem.user = buyer
        newitem.save()
        my_products= mycart.objects.filter(user=buyer)
        print(my_products)

        for item in my_products:
            
            total+= item.quantity*item.item.price
        request.session["total"] = total
        
        return render(request,"shop/showallcartitems.html",{"items":my_products})
    else:
        allProds = []
        catprods = Product.objects.values('category', 'id')
        cats = {item['category'] for item in catprods}
        for cat in cats:
            prod = Product.objects.filter(category=cat)
            n = len(prod)
            nSlides = n // 4 + ceil((n / 4) - (n // 4))
            allProds.append([prod, range(1, nSlides), nSlides])
        params = {'allProds':allProds}
        print(len(params))
        messages.success(request,'Please Login')
        print(str(params))
        return render(request, 'shop/index.html', params)



def address(request):
    return render(request,"shop/checkout.html",{})

def checkout(request):
    if "email" in request.session: 
        name = request.POST['name']
        email = request.POST['email']
        address1 = request.POST['address1']
        address2 = request.POST['address2']
        city = request.POST['city']
        state = request.POST['state']
        zip = request.POST['zip_code']
        phone = request.POST['phone']

        checkout = Orders()
        checkout.name=name
        checkout.email=email
        checkout.address=address1 + " "+ address2
        checkout.city=city
        checkout.state=state
        checkout.zip_code=zip
        checkout.phone=phone
        checkout.name=name
        checkout.save()

        return render(request,"shop/makepayment.html",{})
def updateitem(request,qty):
    if "email" in request.session:
    #qty=MyCart.object.get(id=myid)
        qty=qty
        print(qty)
        uname = request.session["email"]
        user = userdata.objects.get(email = uname) 
        print(str(user))
        id = request.POST["Foodid"]
        print(id)
        p = Product.objects.get(id=id)
        print(str(p))
        item = mycart.objects.get(user=user,item=p)
        item.quantity= qty
        item.save()
        return redirect(showallcartitems)   
    #qty.save()
def removeItem(request):
    if "email" in request.session:
        uname = request.session["email"]
        user = userdata.objects.get(email = uname) 
        id = request.POST["Foodid"]
        Food = Product.objects.get(id=id)
        item = mycart.objects.get(user=user,item=id)
        item.delete()
        return redirect(showallcartitems)   
def MakePayment(request):
    if(request.method == "GET"):
        return render(request,"MakePayment.html",{})
    else:
        cardno = request.POST["cardno"]
        cvv = request.POST["cvv"]
        expiry = request.POST["expiry"]
        try:
            buyer = PaymentMaster.objects.get(cardno=cardno,cvv=cvv,expiry=expiry)
        except:
            return redirect(MakePayment)
        else:
            #Its a match
            owner = PaymentMaster.objects.get(cardno=cardno,cvv=cvv,expiry=expiry)
            owner.balance += request.session["total"]
            buyer.balance -=request.session["total"]
            owner.save()
            buyer.save()
            return render(request,"shop/Successfull.html",{})
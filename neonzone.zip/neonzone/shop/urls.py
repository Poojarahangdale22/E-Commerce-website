from django.urls import path
from.import views

urlpatterns = [
    path("",views.index),
    path("about/",views.about),
    path("contact/",views.contactus),
    path("tracker/",views.tracker),
    path("search/",views.search),
    path("productview/",views.productView),
    path("checkout/",views.checkout),
    path("contact_process/",views.contact_process),
    path("signup",views.signup),
    path("adduser",views.adduser),
    path("login",views.login),
    path("userlogin",views.userlogin),
    path("logout",views.logout),
    path("showallcartitems",views.showallcartitems),
    path("addtocart/<id>",views.addtocart),
    path("address",views.address),
    path("/updateitem/<qty>",views.updateitem),
    path("removeItem",views.removeItem),
    path("checkout/MakePayment",views.MakePayment),






]                                                                                       
